import java.rmi.Naming;
import java.util.Scanner;


public class ClientMagasin 
{

	@SuppressWarnings("resource")
	public static void main(String[] args) 
	{
		try
		{
			
			System.out.println("-----------------------------------------");
			System.out.println("|\t\t M E N U  \t\t|");
			System.out.println("-----------------------------------------");
			System.out.println("| 1. farine\t\t\t\t|");
			System.out.println("| 2. oeuf\t\t\t\t|");
			System.out.println("| 3. levure\t\t\t\t|");
			System.out.println("| 4. lait\t\t\t\t|");
			System.out.println("| 5. beure\t\t\t\t|");
			System.out.println("-----------------------------------------");
	        Scanner sc = new Scanner(System.in);
			String ingrediant;
			do{
		    	System.out.print("l'ingrediant : ");
		    	ingrediant = sc.nextLine();
		    }while(!ingrediant.equals("farine") && !ingrediant.equals("oeuf") && !ingrediant.equals("levure") && !ingrediant.equals("lait")
		    		&& !ingrediant.equals("beure") );
			
			
			InPrix prix1 = (InPrix) Naming.lookup("rmi://localhost:1099/magasin1");
			InPrix prix2 = (InPrix) Naming.lookup("rmi://localhost:1099/magasin2");
			float result1 = prix1.PrixIngrediant(ingrediant);
			float result2 = prix2.PrixIngrediant(ingrediant);
			
			if(result1 <= result2)
				System.out.println ("\nMagasin1 : " + result1 + " DH");
			else
				System.out.println ("\nMagasin2 : " + result2 + " DH");
		}
		catch (Exception e)
		{
			System.out.println ("Erreur d'accès à l'objet distant.");
			System.out.println (e.toString());
		}
	}

}