import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InPrix extends Remote{
   public float PrixIngrediant(String a) throws RemoteException;
}
