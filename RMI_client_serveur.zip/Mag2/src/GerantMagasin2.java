import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class GerantMagasin2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			    String url;
			    try 
				{
					Prix prix = new Prix();
					//LocateRegistry.createRegistry(1099);	
					url ="rmi://localhost:1099/magasin2";
					System.out.println("Ajout au registre...");
					Naming.rebind(url, prix);
					System.out.println("Mag1 en attente de clients");
				}
				catch (Exception e) 
				{
					System.out.println("Erreur de liaison ");
					System.out.println(e.getMessage());
				}
		

}
	}
