import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Prix  extends UnicastRemoteObject implements InPrix{
	
	protected Prix() throws RemoteException{
		super();
	}

	@Override
	public float PrixIngrediant(String a) throws RemoteException {
      float prix = 0;
		
		switch(a)
		{
			case "farine" : prix = (float) 12.0; break;
			case "oeuf" : prix = (float) 8.5; break;
			case "levure" : prix = (float) 10; break;
			case "lait" : prix = (float) 20; break;
			case "beure" : prix = (float) 20.5; break;
			default: prix = 0; break;
		}
		
		return prix;
	}

}
